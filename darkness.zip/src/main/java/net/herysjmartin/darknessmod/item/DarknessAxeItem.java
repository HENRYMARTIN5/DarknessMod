
package net.herysjmartin.darknessmod.item;

import net.minecraftforge.registries.ObjectHolder;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.Item;
import net.minecraft.item.IItemTier;
import net.minecraft.item.AxeItem;

import net.herysjmartin.darknessmod.DarknessmodModElements;

@DarknessmodModElements.ModElement.Tag
public class DarknessAxeItem extends DarknessmodModElements.ModElement {
	@ObjectHolder("darknessmod:darkness_axe")
	public static final Item block = null;
	public DarknessAxeItem(DarknessmodModElements instance) {
		super(instance, 8);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new AxeItem(new IItemTier() {
			public int getMaxUses() {
				return 6280;
			}

			public float getEfficiency() {
				return 100f;
			}

			public float getAttackDamage() {
				return 73f;
			}

			public int getHarvestLevel() {
				return 20;
			}

			public int getEnchantability() {
				return 1000;
			}

			public Ingredient getRepairMaterial() {
				return Ingredient.fromStacks(new ItemStack(DarknessAxeItem.block, (int) (1)), new ItemStack(DarknessDustItem.block, (int) (1)));
			}
		}, 1, -3f, new Item.Properties().group(ItemGroup.TOOLS)) {
			@Override
			@OnlyIn(Dist.CLIENT)
			public boolean hasEffect(ItemStack itemstack) {
				return true;
			}
		}.setRegistryName("darkness_axe"));
	}
}
